print("Submitting Assignment 0")
